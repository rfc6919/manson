#!/usr/bin/python
import mansonlib
import time
import RPi.GPIO as GPIO
button_pin = 23
GPIO.setwarnings(False)
GPIO.setmode( GPIO.BCM )
#GPIO.setup( button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP) 
GPIO.setup( button_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) 
#
def test():
	ntp = mansonlib.NTP()
#	print(ntp.OpenPort('com6'))
	print(ntp.OpenPort('/dev/ttyUSB0'))
	time.sleep(1)
#	print(ntp.DeleteProtection())
	print(ntp.SetOutputCurrent(5.2))
	time.sleep(1)
	print(ntp.OutputOn())
	time.sleep(1)
	v = 2
	while True:
		if GPIO.input(button_pin)==1 and v < 10 and v >= 2:
#			for x in range(30):
			v = v + 0.2
			print(v)
			print(ntp.SetOutputVoltage(v))
			time.sleep(0.5)
	
#			time.sleep(3)
#			for x in range(30):
		elif GPIO.input(button_pin)==0 and v > 2:
			v = v - 0.2
			print(v)
			print(ntp.SetOutputVoltage(v))
			time.sleep(0.5)

		'''
		c = 0.25
		for x in range(475):
			c = c+0.01
			print(c)
			print(ntp.SetOutputCurrent(c))
			time.sleep(0.2)
		'''
#	print(ntp.GetOutputVoltage())
#	print(ntp.GetOutputCurrent())
#	print(ntp.GetOutputMode())
	print(ntp.ClosePort())
	
	
	
if __name__ == '__main__':	
	test()